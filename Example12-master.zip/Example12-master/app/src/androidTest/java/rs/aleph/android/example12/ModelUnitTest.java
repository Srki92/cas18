package rs.aleph.android.example12;

import android.test.suitebuilder.annotation.SmallTest;

import junit.framework.TestCase;

public class ModelUnitTest extends TestCase {

    @Override
    protected void setUp() throws Exception {
        super.setUp();

    }

    @SmallTest
    public void testIsItemCreated(){

    }

    @SmallTest
    public void testIfIconIDNotNegative() {

    }

}
